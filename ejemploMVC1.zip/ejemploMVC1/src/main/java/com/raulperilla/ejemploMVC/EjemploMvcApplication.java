package com.raulperilla.ejemploMVC;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjemploMvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(EjemploMvcApplication.class, args);
	}

}
