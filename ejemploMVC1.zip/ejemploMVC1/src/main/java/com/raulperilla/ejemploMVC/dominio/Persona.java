package com.raulperilla.ejemploMVC.dominio;
import lombok.Data;

@Data
public class Persona {
    private String nombre;
    private String apellido;
    private String email;
    private String telefono;

}
