package com.mycompany.Anonymous.controles;
import com.mycompany.Anonymous.entidades.Enterprises;
import com.mycompany.Anonymous.servicios.servicioEmpresa;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
public class ControladorEmpresa {
    @Autowired
    servicioEmpresa service;

    public ControladorEmpresa(servicioEmpresa service) {
        this.service = service;
    }

    @GetMapping("/enterprises")
    public List<Enterprises> enterpriseLists() {
        return this.service.getEmpresas();
    }

    @PostMapping("/enterprises")
    public Enterprises createEnterprise(@RequestBody Enterprises enterprises) {
        return this.service.createEnterprise(enterprises);
    }

    @PutMapping("/enterprises")
    public String updateEnterprise(@RequestBody Enterprises enterprises) {
        return this.service.createEnterprise(enterprises)  + " " +  "updateEnterprise";
    }

    @GetMapping ("/enterprises/{id}")
    public Enterprises buscarEmpId(@PathVariable("id") Long id) {
        return this.service.getEmpresa(id);
    }
    @PatchMapping ("/enterprises/{id}")
    public Enterprises buscarYEditar(@PathVariable("id") Long id, @RequestBody Enterprises enterprises2) {
        this.service.createEnterprise(enterprises2);
        return this.service.getEmpresa(id);
    }



    @DeleteMapping("/enterprises/{id}")
    private void eliminarEmpresa(@PathVariable("id") Long id) {
        service.eliminarEmpresa(id);
    }
}
