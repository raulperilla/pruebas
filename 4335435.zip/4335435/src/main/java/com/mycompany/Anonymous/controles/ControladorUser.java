package com.mycompany.Anonymous.controles;
import com.mycompany.Anonymous.entidades.Enterprises;
import com.mycompany.Anonymous.entidades.Usuarios;
import com.mycompany.Anonymous.servicios.ServicioUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
public class ControladorUser {
    @Autowired
    ServicioUser uservice;

    public ControladorUser(ServicioUser uservice) {
        this.uservice = uservice;
    }

    @GetMapping("/users")
    public List<Usuarios> userList() {
        return this.uservice.getUsers();
    }

    @GetMapping("/users/{id}")
    public Usuarios userID(@PathVariable("id") Long id) {
        return this.uservice.getuser(id);
    }

    @PostMapping("/users")
    public Usuarios createUser(@RequestBody Usuarios usuarios) {
        return this.uservice.createUser(usuarios);
    }
    @PatchMapping("/users/{id}")
    public Usuarios buscarYEditar(@PathVariable("id") Long idusu, @RequestBody Usuarios usuarios2) {
        this.uservice.createUser(usuarios2);
        return this.uservice.getuser(idusu);
    }


    @PutMapping("/users")
    public String updateUsuario(@RequestBody Usuarios usuarios) {
        return this.uservice.createUser(usuarios) + " " + "updateUsuario";

    }

    @DeleteMapping("/users/{id}")
    private void eliminarUser(@PathVariable("id") Long id) {
        uservice.eliminarUser(id);
    }
}
