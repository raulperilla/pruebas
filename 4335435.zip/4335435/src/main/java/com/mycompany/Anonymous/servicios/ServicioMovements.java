package com.mycompany.Anonymous.servicios;
import com.mycompany.Anonymous.entidades.Movements;

import com.mycompany.Anonymous.repositorios.RepositorioMovementes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ServicioMovements {
    @Autowired
    private RepositorioMovementes Mrepository;

    public ServicioMovements(RepositorioMovementes repository){
        this.Mrepository = repository;
    }
    public List<Movements> getMovements(){
        List<Movements> movimientos = new ArrayList<Movements>();
        movimientos.addAll(Mrepository.findAll());
        return movimientos;
    }
    public Movements createMovement(Movements newMovement){
        return this.Mrepository.save(newMovement);
    }
    public void eliminarmovimiento(Long id){
        Mrepository.deleteById(id);
    }

}