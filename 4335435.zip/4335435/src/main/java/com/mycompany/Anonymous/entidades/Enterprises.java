package com.mycompany.Anonymous.entidades;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


@Entity
@Table(name="enterprise")
@ToString
@Getter
@Setter
public class Enterprises {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;


    @Column(name = "name", nullable = false, unique = true, length = 50)
    private String nombreEmpresa;
    @Column(name = "TelefonoEmpresa")
    private String TelefonoEmpresa;
    @Column(name = "document", nullable = false, unique = true, length = 50)
    private String Nit;
    @Column(name = "address", nullable = false, length = 50)
    private String Direccion;

    @OneToMany(mappedBy = "enterprise", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JsonManagedReference
    private List<Usuarios> employees = new ArrayList<>();

    @OneToMany(mappedBy = "enterprise", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JsonManagedReference
    private List<Movements> transactions = new ArrayList<>();


    @Column(name = "createdAt")
    private Date createdAt;

    @Column(name = "updatedAt")
    private Date updatedAt;

    public Enterprises( Long id,String nombreEmpresa, String Direccion, String TelefonoEmpresa, String Nit) {
        this.id = id;
        this.nombreEmpresa = nombreEmpresa;
        this.Direccion = Direccion;
        this.TelefonoEmpresa = TelefonoEmpresa;
        this.Nit = Nit;
    }
    public Enterprises() {
    }

    /*protected String getNombreEmpresa() {
        return nombreEmpresa;
    }*/
}

