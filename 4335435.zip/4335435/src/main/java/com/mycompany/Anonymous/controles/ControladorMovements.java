package com.mycompany.Anonymous.controles;
import com.mycompany.Anonymous.entidades.Enterprises;
import com.mycompany.Anonymous.entidades.Movements;
import com.mycompany.Anonymous.servicios.ServicioMovements;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
public class ControladorMovements {
    @Autowired
    ServicioMovements mservice;

    public  ControladorMovements (ServicioMovements mservice){
        this.mservice = mservice;
    }

    @GetMapping("/enterprises/{id}/movements")
    public List<Movements> movementsList(){
        return this.mservice.getMovements();
    }

    @PostMapping("/enterprises/{id}/movements")
    public Movements createMovement(@RequestBody Movements movements){
        return  this.mservice.createMovement(movements);
    }
    @PutMapping("/enterprises/{id}/movements")
    public String updateMovement(){
        return "updateMovement";
    }




    @DeleteMapping("/enterprises/{id}/movements")
    private void eliminarmMovim(@PathVariable("id") Long id) {
        mservice.eliminarmovimiento(id);
    }
}
