package com.mycompany.Anonymous.entidades;
import java.util.ArrayList;
import java.util.List;

public class EnterpriseList {
    private List<Enterprises> enterprisesList;
    public EnterpriseList(){
        this.enterprisesList = new ArrayList<>();
    }
    public List<Enterprises> getEnterprisesList() {
        return enterprisesList;
    }
    public void setEnterprisesList(Enterprises enterprises) {
        this.enterprisesList.add(enterprises);
    }
}
