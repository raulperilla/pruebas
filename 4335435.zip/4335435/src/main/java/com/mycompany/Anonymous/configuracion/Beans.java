package com.mycompany.Anonymous.configuracion;

import com.mycompany.Anonymous.entidades.Enterprises;
import com.mycompany.Anonymous.entidades.Movements;
import com.mycompany.Anonymous.entidades.Usuarios;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class Beans {



    @Bean
    public Usuarios employee() {
        return new Usuarios();
    }

    @Bean
    public Movements transaction() {
        return new Movements();
    }

    @Bean
    public Enterprises enterprise() {
        return new Enterprises();
    }

}