package com.mycompany.Anonymous.servicios;
import com.mycompany.Anonymous.entidades.Enterprises;
import com.mycompany.Anonymous.repositorios.RepositorioEmpresa;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class servicioEmpresa {
    
    @Autowired
    private RepositorioEmpresa repository;
    public servicioEmpresa(RepositorioEmpresa Repository) {
        this.repository = Repository;
    }
    public List<Enterprises> getEmpresas(){
        List<Enterprises> Empre1 = new ArrayList<Enterprises>();
        Empre1.addAll(repository.findAll());
        return Empre1;
    }
    public Enterprises createEnterprise(Enterprises enterprises){
        return this.repository.save(enterprises);
    }
    public void eliminarEmpresa(Long id){
        repository.deleteById(id);
    }

    public Enterprises getEmpresa(Long idEmpresa) {
        Optional<Enterprises> empre1 = repository.findById(idEmpresa);
        if (empre1.isPresent()) {
            return empre1.get();
        } else {
            return null;
        }
    }

}





