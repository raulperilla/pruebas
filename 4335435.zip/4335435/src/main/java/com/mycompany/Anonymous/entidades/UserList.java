package com.mycompany.Anonymous.entidades;
import java.util.ArrayList;
import java.util.List;

public class UserList {

    private List<Usuarios> usuariosList;

    public void UserList(){
        this.usuariosList = new ArrayList<>();
    }
    public List<Usuarios> getUserList(){
        return usuariosList;
    }
    public void setUserList (Usuarios usuarios){
        this.usuariosList.add(usuarios);
    }
}
