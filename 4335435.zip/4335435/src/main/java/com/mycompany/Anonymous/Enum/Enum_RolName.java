package com.mycompany.Anonymous.Enum;

import javax.persistence.Table;

@Table(name = "enum_rolname")
public enum Enum_RolName {
    Admin,
    Operario;
}