package com.mycompany.Anonymous.entidades;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;
import java.util.Date;

@Getter
@Setter
@Entity
@Table (name = "movements")
@ToString

public class Movements {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id", nullable = false, unique = true)
    private Long id;


    @Column(name = "amount", nullable = false)
    private double Monto;
/* El concepto del movimiento del dinero*/
    @Column(name = "concept", nullable = false)
    private String Concepto;
/* Usuario encargado de hacer el movimiento*/

    @ManyToOne
    @JoinColumn(name = "employee_id")
    private Usuarios employee;

    @ManyToOne
    @JoinColumn(name = "enterprise_id")
    private Usuarios enterprise;

    @Column(name = "createdAt")
    private Date createdAt;

    @Column(name = "updatedAt")
    private Date updatedAt;

    public Movements(Long id, double monto, String concepto, Usuarios employee, Usuarios enterprise, Date createdAt, Date updatedAt) {
        this.id = id;
        Monto = monto;
        Concepto = concepto;
        this.employee = employee;
        this.enterprise = enterprise;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    public Movements() {
    }
}