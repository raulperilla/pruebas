package com.mycompany.Anonymous;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnonymousApplication {

	public static void main(String[] args) {

		SpringApplication.run(AnonymousApplication.class, args);
	}

}
