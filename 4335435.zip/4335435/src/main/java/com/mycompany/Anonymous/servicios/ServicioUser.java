package com.mycompany.Anonymous.servicios;
import com.mycompany.Anonymous.entidades.Usuarios;
import com.mycompany.Anonymous.repositorios.RepositorioUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class ServicioUser {
    @Autowired
    private RepositorioUser Userpository;



    public ServicioUser(RepositorioUser repository){
        this.Userpository = repository;
    }

    public List<Usuarios> getUsers(){
        List<Usuarios> usuarios23 = new ArrayList<Usuarios>();
        usuarios23.addAll(Userpository.findAll());
        return usuarios23;
    }

    public Usuarios createUser (Usuarios newUsuarios){
        return this.Userpository.save(newUsuarios);
    }
    public void eliminarUser(Long id){
       Userpository.deleteById(id);
    }
    public Usuarios getuser(Long idUser) {
        Optional<Usuarios> user4 = Userpository.findById(idUser);
        if (user4.isPresent()) {
            return user4.get();
        } else {
            return null;
        }


    }

}
