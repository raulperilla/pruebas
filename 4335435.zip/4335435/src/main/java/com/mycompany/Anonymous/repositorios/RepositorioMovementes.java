package com.mycompany.Anonymous.repositorios;
import com.mycompany.Anonymous.entidades.Movements;
import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

@Repository
public interface RepositorioMovementes  extends JpaRepository<Movements, Long> {
}
