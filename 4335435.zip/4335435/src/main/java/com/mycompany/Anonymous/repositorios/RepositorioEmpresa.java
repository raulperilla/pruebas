package com.mycompany.Anonymous.repositorios;
import com.mycompany.Anonymous.entidades.Enterprises;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RepositorioEmpresa extends JpaRepository<Enterprises, Long> {

}
