package com.mycompany.Anonymous.entidades;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.mycompany.Anonymous.Enum.Enum_RolName;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;


@Entity
@Table(name = "employee")
@ToString
@Getter
@Setter
public class Usuarios {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id", nullable = false, unique = true)
    private Long id;

    @Column(name = "email", nullable = false, unique = true, length = 50)
    private String correo;


    @Enumerated(EnumType.STRING)
    @Column(name = "role")
    private Enum_RolName role;

    @ManyToOne
    @JoinColumn(name = "enterprise_id")
    private Enterprises enterprise;

    @OneToMany(mappedBy = "employee", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JsonManagedReference
    private List<Movements> transactions = new ArrayList<>();

    public Usuarios(Long id, String correo, Enum_RolName role, Enterprises enterprise, List<Movements> transactions) {
        this.id = id;
        this.correo = correo;
        this.role = role;
        this.enterprise = enterprise;
        this.transactions = transactions;
    }

    public Usuarios() {

    }
    }




