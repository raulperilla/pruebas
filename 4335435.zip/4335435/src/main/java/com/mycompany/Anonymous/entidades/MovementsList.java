package com.mycompany.Anonymous.entidades;
import java.util.ArrayList;
import java.util.List;

public class MovementsList {
    private List<Movements> movementsList;

    public MovementsList(){
        this.movementsList = new ArrayList<>();
    }

    public List<Movements> getMovementsList() {
        return movementsList;
    }
    public void setMovementsList(Movements movements) {
        this.movementsList.add(movements);
    }
}

