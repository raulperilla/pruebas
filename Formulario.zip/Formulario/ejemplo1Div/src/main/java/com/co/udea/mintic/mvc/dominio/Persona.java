package com.co.udea.mintic.mvc.dominio;

import lombok.Data;

@Data
public class Persona {

}
